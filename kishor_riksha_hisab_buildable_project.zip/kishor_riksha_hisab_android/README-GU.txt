કિશોર રિક્ષા હિસાબ — Android Studio પ્રોજેક્ટ

મહત્વપૂર્ણ:
- આ Android એપનો સોર્સ પ્રોજેક્ટ છે; અહીંથી તૈયાર/સહી કરેલી APK compile થઈ નથી.
- એપ હાલ HTML prototype ને Android WebView માં ખોલે છે.
- ડેટા આ જ ફોનમાં એપના સ્થાનિક સ્ટોરેજમાં રહે છે. ફોન બદલતાં પહેલાં એપમાં ઉપલબ્ધ Backup વિકલ્પથી બેકઅપ લો.
- ઓનલાઈન database/sync, સુરક્ષિત user login, અને production security હજી ઉમેરેલા નથી.

APK બનાવવા:
1. કમ્પ્યુટર પર Android Studio ઇન્સ્ટોલ કરો.
2. Android Studio માં આ ફોલ્ડર (KishorRikshaHisab) Open કરો.
3. Android SDK Platform 35 ઇન્સ્ટોલ કરવા કહે તો સ્વીકારો.
4. Gradle Sync પૂરો થવા દો.
5. Build > Build Bundle(s) / APK(s) > Build APK(s) પસંદ કરો.
6. APK સામાન્ય રીતે app/build/outputs/apk/debug/app-debug.apk માં મળશે.

પ્રોજેક્ટમાં app/src/main/assets/index.html માં ગુજરાતી સોફ્ટવેરનો નમૂનો છે.
